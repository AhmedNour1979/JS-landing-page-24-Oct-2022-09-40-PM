



/**
 *
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 *
 * Dependencies: None
 *
 * JS Version: ES2015/ES6
 *
 * JS Standard: ESlint
 *
*/

/**
 * Comments should be present at the beginning of each procedure and class.
 * Great to have comments before crucial code sections within the procedure.
*/

/**
 * Define Global Variables
 *
*/


/**
 * End Global Variables
 * Start Helper Functions
 *
*/


/**
 * End Helper Functions
 * Begin Main Functions
 *
*/

/**
 * End Main Functions
 * Begin Events
 *
*/


// build the nav
document.addEventListener('DOMContentLoaded',function(event){
    let navbarList=document.querySelector('#navbar__list');
    let sectionsList=document.querySelectorAll('section');
    let fregmant=document.createDocumentFragment();
    sectionsList.forEach(function(element)
    {
        elementAttribute=element.getAttribute('data-nav');
        let listItem=document.createElement('li');
        let newAnchor=document.createElement('a');
        newAnchor.textContent=elementAttribute;
        newAnchor.setAttribute('class','menu__link');
        newAnchor.setAttribute('href','#');
        listItem.appendChild(newAnchor);
        fregmant.appendChild(listItem);
    }
    );
    navbarList.appendChild(fregmant);
});


// Build menu
document.addEventListener('DOMContentLoaded',function(event)
    {
        let menuNav=document.querySelectorAll('.menu__link');
            menuNav.forEach(function(item)
            {
                item.addEventListener('click',menuNavClicked);
            });
    });
    

    // function of click action <<to Eventlistner>> when menu button clicked
    let menuNavClicked= function(event)
    {
        event.preventDefault();
        let menue_Name=event.target.textContent;
        activeMenu(menue_Name);
        scroll_To_Element(menue_Name);
    };
//


// Set menue as active
function activeMenu(menue_Name)
{
    let menue_List=document.querySelectorAll('.menu__link');
    menue_List.forEach(function(item)
    {
        if(item.textContent=== menue_Name)
        {
            //set active style
            item.classList.add('menu__link_active');
        }
        else
        {
            //remove active style
            item.classList.remove('menu__link_active');
        }
    });

}


// Add class 'active' to section when near top of viewport
// Scroll to anchor ID using scrollTO event
document.addEventListener('scroll',function(event)
{
    //define section top position
    let sectionList=this.querySelectorAll('section');
    sectionList.forEach(function(item){        
        if(item.getBoundingClientRect().top>=0 && item.getBoundingClientRect().top<=200)
        {
            activeMenu(item.getAttribute('data-nav'));
            item.classList.add('your-active-class');
        }
        else
        {
            item.classList.remove('your-active-class');
        }
    });
});


// Scroll smoothly to section on link click
function scroll_To_Element(menue_Attribute)
{
    let sectionList=document.querySelectorAll('section');
    sectionList.forEach(function(element)
        {
            if(element.getAttribute('data-nav')===menue_Attribute)
            {
                element.scrollIntoView({behavior: "smooth"});
            }
        }
    );
}


